import java.util.ArrayList;
import java.util.Collections;
enum Genre{
    SCIENCE, ROMANCE, COMIC, CLASSIC, ATHLETIC, BEAUTY, FASHION, ENTERTAINMENT, THRILLER
}
class Publication implements Comparable<Publication>{
    private String title;
    private Genre genre;
    private int edition;
    private int year;
    public Publication(String title, Genre genre, int edition, int year){
        this.title = title;
        this.genre = genre;
        this.edition = edition;
        this.year = year;
    }
    public void printInfo(){
        System.out.println(title +". Edition (" + edition +") published in " + year + " " + getType() + " by " + getAuthorOrPublisher() + ". All rights reserved!");
    }
    public void printFooter(){
        System.out.println("All rights reserved. --------------------");
    }
    public String getType(){
        return getClass().getSimpleName().toLowerCase();
    }
    public String getAuthorOrPublisher(){
        return getClass() == Book.class ? ((Book) this).getAuthor() : ((Magazine) this).getPublisher();
    }
    @Override
    public int compareTo(Publication other){
        int genreComparison = this.genre.compareTo(other.genre);
        return genreComparison != 0 ? genreComparison :
        this.title.compareTo(other.title);
    }
    }
    class Book extends Publication{
        private String author;
        public Book(String author, String title, Genre genre, int edition, int year){
            super(title, genre, edition, year);
            this.author = author;
        }
        public String getAuthor(){
            return author;
        }
    }
    class Magazine extends Publication{
        private String publisher;
        public Magazine(String publisher, String title, Genre genre, int edition, int year){
            super(title, genre, edition, year);
            this.publisher = publisher;
        }
        public String getPublisher(){
            return publisher;
        }
    }
    public class PublicationProject{
        public static void main(String[] args){
           ArrayList<Publication> pubs = new ArrayList<>();
pubs.add(new Book("John Carreyrou", "Bad Blood: Secrets and Lies in a Silicon Valley Startup",
Genre.THRILLER, 1, 2018));
pubs.add(new Book("Andriy Burkov", "The Hundred-Page Machine Learning Book", Genre.SCIENCE, 1,
2019));
pubs.add(new Magazine("Meredith Corporation", "Sports Illustrated", Genre.ATHLETIC, 633, 2020));
pubs.add(new Magazine("Meredith Corporation", "People", Genre.ENTERTAINMENT, 466, 2020));

Collections.sort(pubs);
 for(Publication p : pubs)
 p.printInfo();



        }
    }
